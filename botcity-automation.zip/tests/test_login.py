
from pages.login_page import LoginPage

def test_login():
    login_page = LoginPage()
    
    try:
        login_page.preencher_login("user", "password")
        login_page.clicar_login()
        assert True
    except Exception as e:
        print(f"Erro no login: {e}")
        assert False
