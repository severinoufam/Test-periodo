
from pages.login_page import LoginPage
from utils.logger import log_info, log_error

def run_login_test():
    try:
        login_page = LoginPage()
        login_page.preencher_login("user", "password")
        login_page.clicar_login()
        log_info("Login bem-sucedido")
    except Exception as e:
        log_error(f"Erro no login: {e}")

if __name__ == "__main__":
    run_login_test()
