
from utils.image_recognition import ImageRecognition

class LoginPage(ImageRecognition):
    def preencher_login(self, username, password):
        if self.click_on_image("images/login/campo_usuario.png"):
            self.type(username)
        else:
            raise Exception("Campo de usuário não encontrado")

        if self.click_on_image("images/login/campo_senha.png"):
            self.type(password)
        else:
            raise Exception("Campo de senha não encontrado")

    def clicar_login(self):
        if not self.click_on_image("images/login/botao_login.png"):
            raise Exception("Botão de Login não encontrado")
