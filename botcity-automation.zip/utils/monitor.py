
from screeninfo import get_monitors

def get_active_monitor():
    monitors = get_monitors()
    for monitor in monitors:
        if monitor.is_primary:
            return monitor
    return None

def adjust_for_resolution(x, y, screen_width, screen_height):
    return int(x * screen_width), int(y * screen_height)
