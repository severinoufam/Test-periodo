
from botcity.core import DesktopBot

class ImageRecognition(DesktopBot):
    def click_on_image(self, image_path, confidence=0.8, timeout=5000):
        if self.find(image_path, matching=confidence, waiting_time=timeout):
            self.click()
            return True
        return False
